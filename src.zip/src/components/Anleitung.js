import React, { Component } from 'react'

export class Anleitung extends Component {
    render() {
        return (
            <div>
                <hr />
                <p>
                    Sei ein guter Gastgeber und begrüße jedes Monster das zu deiner Party erscheint.<br />
                    Aber Vorsicht, vergisst du ein Monster zu begrüßen, wird es fuchsteufelswild und 
                    legt die ganze Party lahm! Klicke zum Begrüßen auf ein Monster.
                    Dafür hast du 2 Sekunden Zeit! 
                </p>
                <hr />
            </div>
        )
    }
}

export default Anleitung